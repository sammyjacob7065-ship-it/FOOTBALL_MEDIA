/**
 * Single source of truth for the site's own URL. Used by layout.tsx
 * (metadataBase/OpenGraph), sitemap.ts, robots.ts, and feed.xml/route.ts.
 *
 * Reads from NEXT_PUBLIC_SITE_URL so there's exactly ONE place to update
 * after deploying to your real domain - previously this same literal was
 * hardcoded separately in all 4 files, which meant updating only some of
 * them after launch would leave RSS links / sitemap URLs / robots.txt
 * silently pointing at the placeholder.
 */
export const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://your-site.vercel.app";
